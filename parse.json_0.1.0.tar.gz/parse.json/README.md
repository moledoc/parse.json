## Name 

parse.json

## Synopsis 

This is a package to read json objects into R list or write a R list into json object. This package is written using only R.

## Setup

There are multiple ways to set up the package:

  <!-- TODO: -->
  * Download the whole repository

```sh
git clone https://github.com/moledoc/parse.json.git
```

  <!-- TODO: -->
  * Download the repository as a zip file.
  
  <!-- TODO: -->
  * Download only package source file. Package source file is named as parse.json_<version>.tar.gz.


## Dependecies

This package uses the following additional packages/functions: **data.table**; **utils** function download.file().

## Overview

<!-- TODO: -->

## Notes/Issues/TODOs

* Notes: currently none
* Issues: currently none
* TODO: currently none

## License

This package is available under MIT license.

## Author

Written by
Meelis Utt
